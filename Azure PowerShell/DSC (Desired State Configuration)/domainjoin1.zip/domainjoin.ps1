#Requires -Module xDSCDomainjoin

Configuration DomainJoinConfiguration
{   
    Import-DscResource -ModuleName 'xDSCDomainjoin'
   
    #domain credentials to be given here   
    $secdomainpasswd = ConvertTo-SecureString "Password1" -AsPlainText -Force
    $mydomaincreds = New-Object System.Management.Automation.PSCredential("administrator@sleepygeeks.com", $secdomainpasswd)
   
        
    node $AllNodes.NodeName   
    {
        xDSCDomainjoin JoinDomain
        {
            Domain = 'sleepygeeks'
            Credential = $mydomaincreds
           
        }
    }
}
